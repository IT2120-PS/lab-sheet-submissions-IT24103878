getwd()

setwd("C:\\Users\\It24103878\\Desktop\\Lab 8")

data <-read.table("Data - Lab 8.txt",header=TRUE)

fix(data)
attach(data)

popmn<-mean(Nicotine)
popvar<-var(Nicotine)

##2

samples<-c()
n<-c()

for(i in 1:30){
  s<-sample(Nicotine,5,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste("s",i))
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)


##3
samplemean<-mean(s.means)
samplevars<-var(s.means)


popmn
samplemean

truevar=popvar/5
samplevars

